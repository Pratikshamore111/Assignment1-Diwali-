import java.util.*;
 
class Array21
{
    public static void main (String[] args)
    {
        String[] geeks = {"Rahul", "Utkarsh",
                          "Shubham", "Neelam"};
 
      
        List al = Arrays.asList(geeks);
       
 
        System.out.println(al);
    }
}
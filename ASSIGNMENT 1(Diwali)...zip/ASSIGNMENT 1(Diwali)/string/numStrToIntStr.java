public class numStrToIntStr {

    public static void main(String[] args) {
        String str="999999999";
        System.out.println("String input = "+Integer.parseInt(str));
        System.out.println("Integer Value = "+Integer.valueOf(str));
    }
}
